*C++ API*
=========

.. doxygenpage:: index

Classes
-------

.. doxygenclass:: Tensor
    :members:

.. doxygenclass:: Context
    :members:

Available Customization
-----------------------

.. doxygengroup:: custom

.. doxygennamespace:: sample_dims
