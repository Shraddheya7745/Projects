.. include:: intro.rst
.. include:: performance.rst

Contents
""""""""

.. toctree::
   :maxdepth: 2

   python
   cpp
   dev

.. _supported-operations:

.. include:: algo_platform_tables.rst
